﻿using System;

class ODEV2
{


	static String generateKey(String str, String key)
	{
		int x = str.Length;

		for (int i = 0; ; i++)
		{
			if (x == i)
				i = 0;
			if (key.Length == str.Length)
				break;
			key += (key[i]);
		}
		return key;
	}



	static String sifremetin(String str, String key)
	{
		String sifre_metin = "";

		for (int i = 0; i < str.Length; i++)
		{

			int x = (str[i] + key[i]) % 26; 
			x += 'A';

			sifre_metin += (char)(x);
		}
		return sifre_metin;
	}


	static String originalText(String sifre_metin, String key)
	{
		String orig_text = "";

		for (int i = 0; i < sifre_metin.Length &&
								i < key.Length; i++)
		{

			int x = (sifre_metin[i] -
						key[i] + 26) % 26; 


			x += 'A';
			orig_text += (char)(x);
		}
		return orig_text;
	}

	public static void Main(String[] args)
	{
		Console.WriteLine("METİN GİRİNİZ: ");
		String keyword = "ADKJSDD";

		string strr = Console.ReadLine();
		String key = generateKey(strr, keyword);
		String sifre_metin = sifremetin(strr, key);

		Console.WriteLine("ŞİFRELİ METİN : "
			+ sifre_metin + "\n");

		Console.WriteLine("ŞİFRELENMEMİŞ METİN : "
			+ originalText(sifre_metin, key));






	}
}

	