package ders;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class cal�sma {
	
	//public static void main(String[] args) {
		
		//class CaesarCipher
		//{
			
			public static StringBuffer encrypt(String text, int s)
			{
				StringBuffer result= new StringBuffer();

				for (int i=0; i<text.length(); i++)
				{
					if (Character.isUpperCase(text.charAt(i)))
					{
						char ch = (char)(((int)text.charAt(i) +
										s - 65) % 26 + 65);
						result.append(ch);
					}
					else
					{
						char ch = (char)(((int)text.charAt(i) +
										s - 97) % 26 + 97);
						result.append(ch);
					}
				}
				return result;
			}


			public static void main(String[] args)
			{
				String text = "SAL�HANUREKER";
				int s = 2;
				System.out.println("METIN : " + text);
				System.out.println("ANAHTAR : " + s);
				System.out.println("SIFRELI METIN: " + encrypt(text, s));
			}
		
	}


